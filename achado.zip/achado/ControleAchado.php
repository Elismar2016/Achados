<?php
require_once "Achado.php";
	require_once "AchadoDAO.php";
	require_once "Contato.php";
	require_once "ContatoDAO.php";
	
	$acao = $_GET['acao'];
	if($acao == "cadastrarAchado"){		
	
	   
		$nome = $_POST["nome"];
		$tipo = $_POST["tipo"];
		$foto = $_POST["foto"];
	    $Idcontato = $_POST["Idcontato"];
		
		$achado = new Achado();
		
		$achado->setNome($nome);
		$achado->setTipo($tipo);
			$achado->setFoto($foto);
			
		$achado->setIdcontato($Idcontato);
		
		
		$achadoDAO = new AchadoDAO();
		$achadoDAO->salvar($achado);		
		header('Location: pesquisar.php');	
	}
	if($acao == "buscarAchados"){
		
		$achado = new Achado();
		$achado->setNome($_POST['nome']);
		$achado->setTipo($_POST['tipo']);
		$achadoDAO = new AchadoDAO();
		$listaAchados = $achadoDAO->buscar($achado);
		
		session_start();
		$_SESSION['listaAchados'] =  $listaAchados;
	
		header('Location: telaListarAchados.php');
	}
	
	
	
	
	
	

?>