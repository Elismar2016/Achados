 <head><style>
.centro{
margin-top:5%;
margin-left:10%;
position:absolute;

width:50%;
height:auto;
}
thead{
	background:rgba(0,0,0,0.5);
	color:white;
}

</style>
<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Pesquisar em Achados</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>    

<?php 
include "Achado.php";
		session_start();				
    $listaAchados = $_SESSION['listaAchados'];
		echo "<div class='centro'><img src='logo.png'> ";
		if($listaAchados->count()!=0){
			echo "Achado o sequinte resultado:";
		}else{			
		header('Location: pesquisar.php?erro=1');	
		}
		echo "<table class='table table-striped' border='1px'>";		
echo "<thead class='thead-dark'>

      <tr>
        
        <th>nome/numero</th>
        <th>Tipo</th>
		<th>Foto</th>
      </tr>
    </thead>";
		foreach($listaAchados as $achado) {
			echo "<tr>";
			
			echo "<td>" . $achado->getNome() . "</td>";
			echo "<td>" . $achado->getTipo() . "</td>";
			echo "<td>" . $achado->getFoto() . "</td>";
			echo "</tr>";
			
			}
			echo "</table>";	
			echo "<br>";
			echo "Contate o usuario abaixo .:";
			echo "<table class='table table-striped' border='1px'>";		
echo "<thead class='thead-dark'>

      	
      <tr class='table-success'>
        
        <th>Contato/local</th>
        <th>Fone</th>
		<th>Email</th>
      </tr>
    </thead>";
			echo "<tr>";        
			
			echo "<td>" . $achado->getIdContato()->getNmContato() . "</td>";
			echo "<td>" . $achado->getIdContato()->getFone() . "</td>";
			echo "<td>" . $achado->getIdContato()->getEmail() . "</td>";
		 	echo "</tr>";
		echo "</table>";
		unset($_SESSION['listaAchados']);
		
		?>
		<!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

<!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

<script src="assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'ti-gift',
            	message: "Bem vindo ao <b>Achado</b> - Compartilhe com os seus amigos."

            },{
                type: 'success',
                timer: 4000
            });

    	});
	</script>
		
	
				
