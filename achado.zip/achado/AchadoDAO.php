<?php

	require_once "achado.php";
	require_once "ContatoDAO.php";
	require_once "Conexao.php";

	class AchadoDAO{
	
		function salvar($achado){		

			$conn = Conexao::getConexao();
			
			$idContato = $Contato->getCod();
			$id = $idContato->getId();
			
			$stmt = $conn->prepare("INSERT INTO tb_achados (nome, tipo, foto, idContato) VALUES (:cod, :nome, :tipo, :foto, :idContato)");	
			
			$stmt->bindParam(':nome', $achado->getNome());
			$stmt->bindParam(':tipo', $achado->getTipo());
			$stmt->bindParam(':foto', $achado->getFoto());
			$stmt->bindParam(':idContato', $id);
			
			$stmt->execute();			
		}
		
		function buscar($achado){
			
			$conn = Conexao::getConexao();
						
			$stmt = $conn->prepare("select * from tb_achados where nome = :nome and tipo = :tipo");	
			$stmt->bindParam(':nome', $achado->getNome());
			$stmt->bindParam(':tipo', $achado->getTipo());	
			$stmt->execute();
			
			
				$listaAchados = new ArrayObject();
			//pegar cada linha da resposta e gerar a lista de objtos Achado
			while($reg = $stmt->fetch(PDO::FETCH_OBJ)){
				
				//objeto Achado
				$achado = new Achado();				
				$achado->setId($reg->id);
				$achado->setNome($reg->nome);
				$achado->setTipo($reg->tipo);
				$achado->setFoto($reg->foto);
				$contato = new Contato();				
				
				$contato->setCod($reg->idContato);
				
				//ContatoDAO busca o Contato para setar no objeto Achado 				
				$contatoDAO = new ContatoDAO();
				$contato = $contatoDAO->buscarContatoPeloId($contato);				
				
				$achado->setIdContato($contato);
				$listaAchados->append($achado);					
			}
			
			return $listaAchados;
			
		}
		
		
		
				
	}
	
	
?>