<?php
require_once "Achado.php";
	require_once "AchadoDAO.php";
	require_once "Contato.php";
	require_once "ContatoDAO.php";
	
	$acao = $_GET['acao'];
	if($acao == "cadastrarContato"){

		$nome = $_POST["nmContato"];
		$fone = $_POST["fone"];
		$email = $_POST["email"];
		$senha = $_POST["senha"];
		
		$contato = new Contato();
		
		$contato->setFone($fone);
		$contato->setEmail($email);
		$contato->setNmContato($nmContato);
		$contato->setSenha($senha);
		$contatoDAO->salvar($contato);	
		header('Location: login.php');	
	}
		
		
		
	if($acao == "cadastrarAchado"){		
	
	   
		$nome = $_POST["nome"];
		$tipo = $_POST["tipo"];
		$foto = $_POST["foto"];
	    $Idcontato = $_POST["Idcontato"];
		
		$achado = new Achado();
		
		$achado->setNome($nome);
		$achado->setTipo($tipo);
			$achado->setFoto($foto);
			
		$achado->setIdcontato($Idcontato);
		
		
		$achadoDAO = new AchadoDAO();
		$achadoDAO->salvar($achado);		
		header('Location: pesquisar.php');	
	}
	if($acao == "buscarContatos"){		
		
		$contato = new Contato();
		$contato->setNmContato($_POST['nmContato']);
		
		$contatoDAO = new ContatoDAO();
		$listaContatos = $contatoDAO->buscar($contato);
		
		session_start();
		$_SESSION['listaContatos'] =  $listaContatos;
		
		header('Location: pesquisaContato.php');		
	}
	if($acao == "buscarAchados"){
		
		$achado = new Achado();
		$achado->setNome($_POST['nome']);
		$achado->setTipo($_POST['tipo']);
		$achadoDAO = new AchadoDAO();
		$listaAchados = $achadoDAO->buscar($achado);
		
		session_start();
		$_SESSION['listaAchados'] =  $listaAchados;
	
		header('Location: telaListarAchados.php');
	}
	
	
	
	

?>