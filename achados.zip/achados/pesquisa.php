<?php

	
$nome=$_GET['nome'];


$conexao = new PDO('mysql:host=localhost;dbname=achados','root','');
$comando = $conexao->prepare('SELECT * FROM tb_achados WHERE nome = :n');
$comando->bindParam(':n', $nome);
$comando->execute();
 


if ($linha = $comando->fetch()) {
		
		$id= $linha['id'];
		$nome= $linha['nome'];
		 $contato= $linha['contato'];


	//abrir sessão
		session_start();
		
	$_SESSION['id'] = $id;
		$_SESSION['nome'] = $nome;
		$_SESSION['contato'] = $contato;
		Header('Location: pesquisar.php');
}
?>
deu ruim brother!!