

<?php



session_start();

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* {
  box-sizing: border-box;
}
body {
  font: 16px Arial; 
width:380px;
height:auto;  
}
.autocomplete {
  /*the container must be positioned relative:*/
  position: relative;
  display: inline-block;
}
input {
	max-width:180px;
  border: 1px solid ;
  background-color: #f1f1f1;
  padding: 10px;
  font-size: 16px;
}
input[type=text] {
  background-color: #f1f1f1;
  width: 100%;
}
input[type=submit] {
  background-color: DodgerBlue;
  color: #fff;
  cursor: pointer;
}

.centro{
margin-top:10%;
margin-left:10%;
position:absolute;

width:50%;
height:auto;
}

</style>
<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Pesquisar em Achados</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>     

<body>

<div class="centro">
<img src="assets/img/logo.png">
 <?php
if (isset($_GET['erro'])) {
					 
					 if ($_GET['erro'] == 1) {
						echo '<strong><span style="color:#ff0000;">Atenção:</span> Não achamos, digite novamente, mas nao desista volte depois!</strong>';
					 }
					 
					 elseif ($_GET['erro'] == 2) {
						echo '<strong><span style="color:#ff0000;">Atenção:</span> Refaça a busca, ou , volte mais tarde.</strong>';						 
					 }
				 }
?>        <!--Make sure the form has the autocomplete function switched off:-->
        <form autocomplete="off" action="controleAchado.php?acao=buscarAchados" method="POST" >   <!--controle.php:-->
  <div class="autocomplete" style="width:300px;">
   <label>Documento: &nbsp &nbsp &nbsp &nbsp &nbsp</label><select name="tipo" > 
	<option>RG</option>
	<option>CPF</option>
	<option>CTPS</option>
	<option>Certidao</option>
	<option>CNH</option>
	<option>Celular</option>
	<option>Tablet</option>
	<option>NoteBook</option>
	</select>
	<br>
	<label>Nome ou Numero</label> <input id="nome" type="text" name="nome" placeholder="nome ou numero" value="16119732">
  </div>
  <input class="btn btn-success " type="submit" value="Pesquisar">
  <h5>

 </h5>
</form>
</div>



	

</body>
<!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

<!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

<script src="assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'ti-gift',
            	message: "Bem vindo ao <b>Achados</b> - Compartilhe com os seus amigos."

            },{
                type: 'success',
                timer: 4000
            });

    	});
	</script>
</html>
