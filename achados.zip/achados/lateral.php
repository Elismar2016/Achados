
 <!--menu lateral-->

    <div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                    Achados
                </a>
            </div>

            <ul class="nav">
                   <li class="<?php if ($_SERVER['SCRIPT_NAME'] == '/achados/painel.php') { echo 'active';}?>">
                    <a href="painel.php">
                        <i class="ti-panel"></i>
                        <p>Painel</p>
                    </a>
                </li>
               <li class="<?php if ($_SERVER['SCRIPT_NAME'] == '/achados/usuario.php') { echo 'active';}?>">
                    <a href="usuario.php">
                        <i class="ti-user"></i>
                        <p>Usuario</p>
                    </a>
                </li>
                <li>
                    <a href="ControleAchado.php?acao=buscarTodosAchados">
                        <i class="ti-view-list-alt"></i>
                        <p>Achados</p>
                    </a>
                </li>
                
            </ul>
    	</div>
    </div>
 <!--menu lateral-->