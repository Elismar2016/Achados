<?php require 'topo.php'; ?>
<?php require 'lateral.php'; 
session_start();?>
<?php
$a = 0;
include 'contador.php';
if (isset($_COOKIE['counte'])) {
  $counte = $_COOKIE['counte'] + 1;
}else{
$counte = 1;
$a++; 
}
setcookie('counte', "$counte", time()+3700);
$abre =@fopen("contador.php","w");
 $ss ='<?php $a='.$a.'; ?>';
 $escreve =fwrite($abre, $ss);
 ?>
<!-- topo entra aqui -->
<!-- menu lateral entra aqui -->
  <body>  <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Menu</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Login</a>
                </div>
                <div class="collapse navbar-collapse">
                   <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="usuario.php" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-user"></i>
								<p>Usuario</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="ti-user"></i>
                                    <p class="notification"><?php 
                                              echo "$a";
                                            ?>  </p>
									<p>Visitantes</p>
									<b class="caret"></b>
                              </a>
                             
                        </li>
						<li>
                            <a href="#">
								<i class="ti-pulse"></i>
								<p><?php 
                                              echo $counte;
                                            ?></p>
                            </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row"><h5>Bem vindo <strong>
		<?php
          if (isset($_SESSION['id'])){ echo  $_SESSION['email'];}else { echo 'Usuario ';}
   
	
							
																?></strong>, é bom vê-lo novamente.</h5>
                   
                        <div class="card">
                            <div class="content">
                                <div class="row">
								     
                   
                                    



<div class="center"style="padding:10px;">
<img src="assets/img/logo.png">
<br>
 <?php
if (isset($_GET['erro'])) {
					 
					 if ($_GET['erro'] == 1) {
						echo '<strong><span style="color:#ff0000;">Atenção:</span> Não achamos, digite novamente, mas nao desista volte depois!</strong>';
					 }
					 
					 elseif ($_GET['erro'] == 2) {
						echo '<strong><span style="color:#ff0000;">Atenção:</span> Refaça a busca, ou , volte mais tarde.</strong>';						 
					 }
				 }
?>        <!--Make sure the form has the autocomplete function switched off:-->
<br>       
	    <!-- Form Elements -->
                    <div class="panel panel-default">
                        <div class="panel-heading"></div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-6">
								<form method="post" action="controleUsuario.php?acao=login">
									<label for="email">E-mail</label>
									<input name="email" type="text" id="email" class="form-control" placeholder="nome@exemplo.com.br" required>
									<label for="senha">Senha</label>
									<input name="senha" type="password" id="senha" class="form-control" required>
									
									<input type="submit" class="btn btn-success" value="Enviar" style="margin-top: 10px;"> Não tem um login? <a href="cadastro.php">CADASTRE-SE.</a>
								</form>
								<a href="confirmaEmail.php" class="btn btn-danger btn-xs" style="margin-top: 10px;">Esqueci minha senha</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Form Elements -->
</div>



	

</body>
<!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

                
</div></div></div></div></div></div>

       <?php require 'footer.php';?>
 

</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'ti-gift',
            message: "Bem vindo ao <b>Achados</b> - Compartilhe com os seus amigos."
            },{
                type: 'success',
                timer: 4000
            });

    	});
	</script>

</html>
