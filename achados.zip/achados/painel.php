<?php require 'topo.php'; ?>
<?php require 'lateral.php'; 
session_start();?>
<?php
$a = 0;
include 'contador.php';
if (isset($_COOKIE['counte'])) {
  $counte = $_COOKIE['counte'] + 1;
}else{
$counte = 1;
$a++; 
}
setcookie('counte', "$counte", time()+3700);
$abre =@fopen("contador.php","w");
 $ss ='<?php $a='.$a.'; ?>';
 $escreve =fwrite($abre, $ss);
 ?>
<!-- topo entra aqui -->
<!-- menu lateral entra aqui -->
   <body > 
     <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Menu</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#"></a>
                </div>
				<br>
				  <h5>Bem vindo <strong>
		<?php
          if (isset($_SESSION['id'])){ echo  $_SESSION['email'];}else { echo 'Usuario ';}
   
	
							
																?></strong>, é bom vê-lo novamente.</h5>
                   
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="usuario.php" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-user"></i>
								<p>Usuario</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="ti-user"></i>
                                    <p class="notification"><?php 
                                              echo "$a";
                                            ?>  </p>
									<p>Visitantes</p>
									<b class="caret"></b>
                              </a>
                             
                        </li>
						<li>
                            <a href="#">
								<i class="ti-pulse"></i>
								<p><?php 
                                              echo $counte;
                                            ?></p>
                            </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="content">
                                <div class="row">
								   
                                    <a href="pesquisar.php"> <div class="col-xs-5">
                                        <div class="icon-big icon-warning text-center">
                                           <i class="ti-list"></i>
                                        </div>
                                    </div>
                                    <div class="col-xs-7">
                                        <div class="numbers">
                                            <p>Registro</p>
                                            1
                                        </div>
                                    </div>
                                </div>
                                <div class="footer">
                                    <hr />
                                    <div class="stats">
                                        <i class="ti-reload"></i> Pesquise agora
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div></a>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-xs-5">
                                        <div class="icon-big icon-success text-center">
                                            <i class="ti-user"></i>
                                        </div>
                                    </div>
                                    <div class="col-xs-7">
                                        <div class="numbers">
                                            <p>Visitante</p>
                                            <?php 
                                              echo "$a";
                                            ?>  


                                            <?php $a=0; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="footer">
                                    <hr />
                                    <div class="stats">
                                        <i class="ti-calendar"></i> Numero atual
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-xs-5">
                                        <div class="icon-big icon-danger text-center">
                                            <i class="ti-pulse"></i>
                                        </div>
                                    </div>
                                    <div class="col-xs-7">
                                        <div class="numbers">
                                            <p>Frequencia</p>
                                           <?php 
                                              echo $counte;
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="footer">
                                    <hr />
                                    <div class="stats">
                                        <i class="ti-timer"></i> Estamos honrados
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-xs-5">
                                        <div class="icon-big icon-info text-center">
                                            <i class="ti-wallet"></i>
                                        </div>
                                    </div>
                                    <div class="col-xs-7">
                                        <div class="numbers">
                                            <p>Recuperado</p>
                                           1
                                        </div>
                                    </div>
                                </div>
                                <div class="footer">
                                    <hr />
                                    <div class="stats">
                                        <i class="ti-reload"></i> Item devolvido
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Digulgando</h4>
                                <p class="category">Achados</p>
                            </div>
                            <div class="content">
                                <div id="" class="">
								<img src="assets/img/caixa.png"></div>
                                <div class="footer">
                                    O sistema de busca de Achados , destina-se à localização de objetos cujos proprietários possam ser identificados, tais como documentos, agendas, pastas e carteiras.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Economia </h4>
                                <p class="category">folha e manutenção</p>
                            </div>
                            <div class="content">
                                <div > 	<img src="assets/img/custo.png"></div>
								

                                <div class="footer">
                                  "Para o cidadão, há economia no custo de deslocamento, de tempo, de recursos financeiros para obter documentos; e no lado do Estado, é mais eficiente pois gasta menos, é mais barato atender o cidadão no meio digital."
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card ">
                            <div class="header">
                                <h4 class="title">Redução de gastos</h4>
                                <p class="category">evitar desperdicio</p>
                            </div>
                            <div class="content">
                                <div id="" class="">

As ações visam integrar os serviços do governo, uma transação em um serviço digital é 97% mais barata do que uma transação entregue no balcão.</div>

                                <div class="footer">
                                    "Para o cidadão, esse benefício é em torno de 8,5 vezes a mais. A cada um real que economizo no governo, economiza-se R$ 8,50 na sociedade. Esse cidadão que não precisa mais ficar em fila está produzindo, consumindo, fazendo turismo, descanso e usando seu tempo como acha mais adequado e faz a economia girar", explica o Diretor de Modernização da Gestão Pública do Ministério do Planejamento, Luis Felipe Salin. 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php require 'footer.php';?>
    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'ti-gift',
            message: "Bem vindo ao <b>Achados</b> - Compartilhe com os seus amigos."
            },{
                type: 'success',
                timer: 4000
            });

    	});
	</script>

</html>
