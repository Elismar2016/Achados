<?php

	
	class Contato{		
		
		private $cod;
		private $nmContato;
		private $fone;
		private $email;
		private $senha;
		private $foto;
		
		function Contato(){
			$this->cod = "";
			$this->nmContato ="";
			$this->fone = "";
			$this->email = "";	
			$this->senha = "";
			$this->foto = "";
		}
		function getFoto() {
			return $this->foto;
		}
		function setFoto($foto) {
			$this->foto = $foto;
		}
		function getCod() {
			return $this->cod;
		}
		function setCod($cod) {
			$this->cod = $cod;
		}
		function getNmContato() {
			return $this->nmContato;
		}
		function setNmContato($nmContato) {
			$this->nmContato = $nmContato;
		}
		function getFone() {
			return $this->fone;
		}
		function setFone($fone) {
			$this->fone = $fone;
		}		
		function getEmail() {
			return $this->email;
		}
		function setEmail($email) {
			$this->email = $email;
		}
		function getSenha() {
			return $this->senha;
		}
		function setSenha($senha) {
			$this->senha = $senha;
		}
	}


?> 