-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 02-Maio-2018 às 14:45
-- Versão do servidor: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `achados`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `contatos`
--

CREATE TABLE `contatos` (
  `cod` int(11) NOT NULL,
  `nmContato` varchar(255) NOT NULL,
  `fone` varchar(16) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(32) NOT NULL,
  `foto` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `contatos`
--

INSERT INTO `contatos` (`cod`, `nmContato`, `fone`, `email`, `senha`, `foto`) VALUES
(1, 'elismar', '9999', 'elismar@elismar', '1111111', 'elismar'),
(2, 'marlon', '888', 'marlon@marlon', '222222', 'marlon');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_achados`
--

CREATE TABLE `tb_achados` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `idContato` int(11) NOT NULL,
  `tipo` varchar(32) NOT NULL,
  `foto` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_achados`
--

INSERT INTO `tb_achados` (`id`, `nome`, `idContato`, `tipo`, `foto`) VALUES
(1, '16119733', 1, 'rg', 'foto'),
(2, '16119731', 2, 'rg', 'foto'),
(3, '16119732', 2, 'RG', 'foto'),
(6, '123', 1, 'rg', '3'),
(12, '123', 1, 'RG', 'd4b8436e4a68d2ea31f1a98d95995fca'),
(16, 'ELISMAR OLIMPIO DOS SANTOS', 1, 'RG', 'ab5916b1f3cf28a669703a4fe1b59dd7'),
(17, '123212132', 1, 'RG', '63fafd33f6d4d2d06c7d19b2acbd0ddf'),
(18, '3333333', 1, 'RG', 'c1b19b85c98ac5e1f0d164f0ff680ec2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contatos`
--
ALTER TABLE `contatos`
  ADD PRIMARY KEY (`cod`) USING BTREE;

--
-- Indexes for table `tb_achados`
--
ALTER TABLE `tb_achados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idContato` (`idContato`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contatos`
--
ALTER TABLE `contatos`
  MODIFY `cod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_achados`
--
ALTER TABLE `tb_achados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `tb_achados`
--
ALTER TABLE `tb_achados`
  ADD CONSTRAINT `tb_achados_ibfk_1` FOREIGN KEY (`idContato`) REFERENCES `contatos` (`cod`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
