<?php 
    require 'topo.php'; 
    require 'lateral.php';
    include "Achado.php";
	session_start();
	if (!isset($_SESSION['listaAchados'])) {
	header('Location: pesquisar.php?erro=2');
}
	?>
	<?php
$a = 0;
include 'contador.php';
if (isset($_COOKIE['counte'])) {
  $counte = $_COOKIE['counte'] + 1;
}else{
$counte = 1;
$a++; 
}
setcookie('counte', "$counte", time()+3700);
$abre =@fopen("contador.php","w");
 $ss ='<?php $a='.$a.'; ?>';
 $escreve =fwrite($abre, $ss);
 ?>
<!-- topo entra aqui -->
<!-- menu lateral entra aqui -->
<!-- topo entra aqui -->
<!-- menu lateral entra aqui -->
  <body>  <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Menu</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Lista de Busca</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="usuario.php" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-user"></i>
								<p>Usuario</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="ti-user"></i>
                                    <p class="notification"><?php 
                                              echo "$a";
                                            ?>  </p>
									<p>Visitantes</p>
									<b class="caret"></b>
                              </a>
                             
                        </li>
						<li>
                            <a href="#">
								<i class="ti-pulse"></i>
								<p><?php 
                                              echo $counte;
                                            ?></p>
                            </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    
                        <div class="card">
                            <div class="content">
                                <div class="row">
								     
                   
   <?php 
  	
		if (!isset($_SESSION['listaAchados'])) {
	header('Location: pesquisar.php?erro=2');
}
    $listaAchados = $_SESSION['listaAchados'];
		echo "<div class='centro'style='padding:10px;'><img src='assets/img/logo.png'> <br>";
		if($listaAchados->count()!=0){
			echo "Achado o sequinte resultado:";
		}else{			
		header('Location: pesquisar.php?erro=1');	
		}
		echo "<table class='table table-striped' border='1px'>";		
echo "<thead class='thead-dark'>

      <tr>
        
        <th>nome/numero</th>
        <th>Tipo</th>
		<th>Foto</th>
      </tr>
    </thead>";
		foreach($listaAchados as $achado) {
			echo "<tr>";
			
			echo "<td>" . $achado->getNome() . "</td>";
			echo "<td>" . $achado->getTipo() . "</td>";
		
			echo "<td> <img src='assets/fotos/". $achado->getFoto(). ".png'></td>";
			echo "</tr>";
			
			}
			echo "</table>";	
			echo "<br>";
			echo "Contate o usuario abaixo .:";
			echo "<table class='table table-striped' border='1px'>";		
echo "<thead class='thead-dark'>

      	
      <tr class='table-success'>
        
        <th>Contato/local</th>
        <th>Fone</th>
		<th>Email</th>
      </tr>
    </thead>";
			echo "<tr>";        
			
			echo "<td>" . $achado->getIdContato()->getNmContato() . "</td>";
			echo "<td>" . $achado->getIdContato()->getFone() . "</td>";
			echo "<td>" . $achado->getIdContato()->getEmail() . "</td>";
		 	echo "</tr>";
		echo "</table>";
		unset($_SESSION['listaAchados']);
		
		?>                                  







	



                
</div></div></div></div></div></div>

        <?php require 'footer.php';?>
</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'ti-gift',
            message: "Bem vindo ao <b>Achados</b> - Compartilhe com os seus amigos."
            },{
                type: 'success',
                timer: 4000
            });

    	});
	</script>

</html>
