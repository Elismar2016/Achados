 <head><style>
.centro{
margin-top:20%;
margin-left:20%;
position:absolute;

width:50%;
height:auto;
}

</style>
 <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
 </head>
<?php 
include "Achado.php";

		session_start();
		
		
    $listaAchados = $_SESSION['listaAchados'];
		echo "<div class='centro'>";
		if($listaAchados->count()!=0){
			echo "Achei!!! "  ;
		}else{
			
		header('Location: pesquisar.php?erro=1');	
		}
		echo "<table class='table' border='1px'>";		
echo "<thead>
      <tr>
        <th>ID</th>
        <th>nome/numero</th>
        <th>Tipo</th>
		<th>Foto</th>
      </tr>
    </thead>";
		foreach($listaAchados as $achado) {
			echo "<tr>";
			echo "<td>" . $achado->getId() . "</td>";
			echo "<td>" . $achado->getNome() . "</td>";
			echo "<td>" . $achado->getTipo() . "</td>";
			echo "<td>" . $achado->getFoto() . "</td>";
			echo "</tr>";
			$id=$achado->getIdContato();
		} 	
		unset($_SESSION['listaAchados']);
		
		echo "</table>";
		echo "<a href='controleRN.php?acao=BuscarPeloId&id=".$id."'>onde esta o achado?</a>";
		?>
				
