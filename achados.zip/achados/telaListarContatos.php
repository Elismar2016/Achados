 <head><style>


</style>
 <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
 </head>
<?php 
include "Contato.php";
		session_start();
	$listaContatos = $_SESSION['listaContatos'];	
		echo "<div class='centro'>";
		if($listaContatos->count()!=0){
			echo "Achei!!! "  ;
		}else{			
				header('Location: pesquisar.php?erro=2');	
		}
		echo "<table class='table' border='1px'>";		
echo "<thead>
      <tr>        
        <th>Nome</th>
        <th>Fone</th>
		<th>Email</th>
      </tr>
    </thead>";
		foreach($listaContatos as $contato) {
			echo "<tr>";		
			echo "<td>" . $contato->getNmContato() . "</td>";
			echo "<td>" . $contato->getFone() . "</td>";
			echo "<td>" . $contato->getEmail() . "</td>";
			echo "</tr>";			
		} 	
			
		echo "</table>";
		unset($_SESSION['listaContatos']);		
		?>
		
		
		
		
				
