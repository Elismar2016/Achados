<?php

	require_once "Contato.php";
	
	class Achado{		
		
		private $id;
		private $nome;
		private $tipo;
		private $idContato;
		private $foto;
		
		function Achado(){
			$this->id = "";
			$this->nome ="";
			$this->tipo = "";
			$this->foto = "";
			$this->idContato = new Contato();			
		}
		
		function getId() {
			return $this->id;
		}
		function setId($id) {
			$this->id = $id;
		}
		function getNome() {
			return $this->nome;
		}
		function setNome($nome) {
			$this->nome = $nome;
		}
		function getTipo() {
			return $this->tipo;
		}
		function setTipo($tipo) {
			$this->tipo = $tipo;
		}		
		function getIdContato() {
			return $this->idContato;
		}
		function setIdContato($idContato) {
			$this->idContato = $idContato;
		}
		function getFoto() {
			return $this->foto;
		}
		function setFoto($foto) {
			$this->foto = $foto;
		}
	}


?> 