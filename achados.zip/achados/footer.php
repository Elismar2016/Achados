 <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="http://www.ifac.edu.br">
                                Academicos IFAC
                            </a>
                        </li>
                        <li>
                            <a href="http://elismar.dyndns.ws:1025/blog.php">
                               Blog Elismar
                            </a>
                        </li>
                        
                    </ul>
                </nav>
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, feito com <i class="fa fa-heart heart"></i> o Template Creative Tim
                </div>
            </div>
        </footer>
