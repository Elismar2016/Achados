<?php

	require_once "Contato.php";
	require_once "ContatoDAO.php";
	
	$acao = $_GET['acao'];
	
	if($acao == "cadastrarContato"){

		$nome = $_POST["nmContato"];
		$fone = $_POST["fone"];
		$email = $_POST["email"];
		$senha = $_POST["senha"];
		
		$contato = new Contato();
		
		$contato->setFone($fone);
		$contato->setEmail($email);
		$contato->setNmContato($nmContato);
		$contato->setSenha($senha);
		$contatoDAO->salvar($contato);	
		header('Location: login.php');	
	}
		
		
		
	
	if($acao == "buscarUsuario"){		
		echo "cheguei na acao buscar usuario";
		echo "<br>";
		echo "trazendo o id do usuario : ".$_POST['id'];
		echo "<br>";
				
		
	$contato = new Contato();
		$contato->setCod($_POST['id']);
			echo "e se o id repetir aqui, entao o objeto contato ja esta setado com  cod".$contato->getCod();
			echo "<br>";
		$contatoDAO = new ContatoDAO();
		
			$listaContatos = $contatoDAO->buscar($contato);
			echo "<br>";
		
			
		$_SESSION['listaContatos'] =  $listaContatos;
	header('Location: telaListarContatos.php');
	}
	if($acao == "login"){		
		
		
	$contato = new Contato();
		$contato->setEmail($_POST['email']);
			$contato->setSenha($_POST['senha']);
			
		$contatoDAO = new ContatoDAO();
		
			$contato = $contatoDAO->logar($contato);
			
			session_start();
		$_SESSION['id'] = $contato->getCod();
		$_SESSION['email'] = $contato->getEmail();
		$_SESSION['nome'] = $contato->getNmContato();
		$_SESSION['foto'] = $contato->getFoto();
			$_SESSION['fone'] = $contato->getFone();
		Header('Location: painel.php');
		
	}
		
	
?>