<?php

	
$nome=$_GET['nome'];


$conexao = new PDO('mysql:host=localhost;dbname=achados','root','');
$comando = $conexao->prepare('SELECT nome FROM tb_achados WHERE nome = :n');
$comando->bindParam(':n', $nome);
$comando->execute();
 


if ($linha = $comando->fetch()) {
		
		$nome= $linha['nome'];
		
		 


	//abrir sessão
		session_start();
		
	$_SESSION['nome'] = $nome;
		
		
		Header('Location: http://localhost/achados/index.php');
}
?>
deu ruim brother!!